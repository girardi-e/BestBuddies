require "test_helper"

class AdoptionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
